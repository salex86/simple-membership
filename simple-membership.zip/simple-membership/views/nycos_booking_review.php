<?php
require_once(SIMPLE_WP_MEMBERSHIP_PATH.'/lib/SagePay.php');
require_once(SIMPLE_WP_MEMBERSHIP_PATH.'/lib/NycosAPI.php');
session_start();
$nycosAPI = new NycosAPI();

$auth = SwpmAuth::get_instance();
$user_data = (array) $auth->userData;

extract($user_data, EXTR_SKIP);
$contact = $nycosAPI->getAPI('contacts/'.$extra_info,'');

$txCode= rand(0,32000)*rand(0,32000);

if (empty($_REQUEST["bookingId"])){
    echo "You accesed this page from an unknown location";
    return;
}

$booking = $nycosAPI->getEventBooking($_REQUEST['bookingId']);

$txCode= rand(0,32000)*rand(0,32000);

$_SESSION["payStart"] = "start";

//check if Booking is set

    $sagePay = new SagePay();
    $sagePay->setCurrency('GBP');
    $sagePay->setAmount($_REQUEST['amount']); // where to get amount of the membership type from?????
    $sagePay->setVendorTxCode($txCode);
    $sagePay->setDescription("Partial payment for" . $booking->eventId);
    $sagePay->setBillingSurname($contact->keyname);
    $sagePay->setBillingFirstnames($contact->firstName);
    $sagePay->setBillingCity($contact->town);
    $sagePay->setBillingPostCode($contact->postcode);
    $sagePay->setBillingAddress1($contact->address);
    $sagePay->setBillingCountry('GB');
    $sagePay->setDeliverySameAsBilling();
    $sagePay->setSuccessURL('https://nycos.co.uk/nycos-booking-confirmation?bookingId='.$_REQUEST['bookingId']);
    $sagePay->setFailureURL('https://nycos.co.uk/nycos-booking-confirmation?bookingId='.$_REQUEST['bookingId']);
?>

<div class="mt-3">
    <fieldset>
        <legend>Review Your Booking Payment</legend>
        <table class="autoSummary">
            <tbody>
                <tr>
                    <td class="left">Our reference:</td>
                    <td id="ctl00_cp1_PLEDGEID" class="right">
                        <?= $booking->eventId ?>
                    </td>
                </tr>
                <tr>
                    <td class="left">Balance:</td>
                    <td id="ctl00_cp1_DESCRIPTION" class="right">
                        &pound; <?= $booking->outstanding ?>
                    </td>
                </tr>
                <tr>
                    <td class="left">Currently Paying</td>
                    <td id="ctl00_cp1_TOTALAMOUNT" class="right">
                      &pound; <?= $_REQUEST['amount'] ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <br />

    </fieldset>
</div>

<div class="mt-3">
    <div class="alert alert-warning" role="alert">
        <h4 class="alert-heading">WARNING</h4>
        <form method="POST" id="SagePayForm" action="https://live.sagepay.com/gateway/service/vspform-register.vsp">
            <input type="hidden" name="VPSProtocol" value="3.00" />
            <input type="hidden" name="TxType" value="PAYMENT" />
            <input type="hidden" name="Vendor" value="NYCOS" />
            <input type="hidden" name="Crypt" value="<?php  echo $sagePay->getCrypt(); ?>" />
            <button class="btn btn-primary submit-btn" type="submit">Next</button>
        </form>
        <p>Do not leave the processing page until your payment has been confirmed.</p>
    </div>

</div>