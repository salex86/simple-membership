<?php
SwpmLog::log_simple_debug( 'Payment for existing membership made by '.print_r($_REQUEST,true), true );

if (empty($_SESSION["memberStart"])){
    print "There has been an error or you have refreshed the page in error. Please contact NYCOS, quoting this message BookErr01";
    return;
}

if($_REQUEST['crypt']){
    $sagePay = new SagePay();
    $responseArray = $sagePay->decode($_REQUEST['crypt']);

    $orderid = $responseArray['VendorTxCode'];
    $amount = $responseArray['Amount'];

    if($responseArray['Status'] === "OK"){

        $payment = $nycosAPI->postCurrentMembershipPayment($orderid,$amount,$contact->serialNumber,$membership->membershipId);

        SwpmLog::log_simple_debug( 'Payment for existing membership made by '.print_r($contact,true), true );

        SwpmLog::log_simple_debug( 'Payment for existing membership returns '.print_r($payment,true), true );

        //print $batchId;
        $responseMessage = "Payment for membership successfull, an email with confirmation will be on its way to you";
    }elseif($responseArray['Status'] === "ABORT"){
        // Payment Cancelled
        $responseMessage = "Card Payment Aborted";
    }else{
        // Payment Failed
        $responseMessage = "Card Payment Failed";
    }

}
$_SESSION["memberStart"] = "";
?>

<h2 class="font-normal">Confirmation</h2>
<!-- Step 4 confirmation input fields -->
<div class="mt-3">
    <?= $responseMessage ?>
</div>
<a href="/nycos-memberships" id="backHome" class="btn btn-primary">View Memberships</a>