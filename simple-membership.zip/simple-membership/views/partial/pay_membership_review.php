<?php
require_once(SIMPLE_WP_MEMBERSHIP_PATH.'/lib/ElavonAPI.php');

$elavonAPI = new ElavonAPI();

$order = $elavonAPI->CreateOrder($membership->nextPaymentAmount,$membership->membershipDetailId)->href;
$session = $elavonAPI->CreatePaymentSession($order);

print_r($session);

$_SESSION['memberStart'] = "start";

//check if membershipDetail is set


     SwpmLog::log_simple_debug( 'Payment for existing membership review '.print_r($contact,true), true );
?>
<script src="https://uat.hpp.converge.eu.elavonaws.com/client/library.js"></script>
<div class="mt-3">
    <fieldset>
        <legend>Review Your Membership Payment</legend>
        <table class="autoSummary">
            <tbody>
                <tr>
                    <td class="left">Our reference:</td>
                    <td id="ctl00_cp1_PLEDGEID" class="right">
                        <?= $membership->membershipDetailId ?>
                    </td>
                </tr>
                <tr>
                    <td class="left">Membership description:</td>
                    <td id="ctl00_cp1_DESCRIPTION" class="right">
                        <?= $membership->schemeName ?>
                    </td>
                </tr>
                <tr>
                    <td class="left">Total to pay:</td>
                    <td id="ctl00_cp1_TOTALAMOUNT" class="right">
                      &pound; <?= $membership->nextPaymentAmount ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <br />

    </fieldset>
</div>

<div class="mt-3">
    <div class="alert alert-warning" role="alert">
        <h4 class="alert-heading">WARNING</h4>
        
        <p>Do not leave the processing page until your payment has been confirmed.</p>
    </div>
   
</div>

<script type="text/javascript">
    const MessageTypes = window.ConvergeLightbox.MessageTypes;

    const submitData = (data) => {
      // send data to your server
      console.log(data);
    };

    let lightbox;

    function onClickHandler() {
      // do work to create a sessionId
      const sessionId = '<?= $session->id ?>';
      if (!lightbox) {
        lightbox = new window.ConvergeLightbox({
          sessionId: sessionId,
          onReady: (error) =>
            error
              ? console.error('Lightbox failed to load')
              : lightbox.show(),
          messageHandler: (message, defaultAction) => {
            switch (message.type) {
              case MessageTypes.transactionCreated:
                submitData({
                  sessionId: message.sessionId,
                });
                break;
              case MessageTypes.hostedCardCreated:
                submitData({
                  convergePaymentToken: message.hostedCard,
                  hostedCard: message.hostedCard,
                  sessionId: message.sessionId,
                });
                break;
            }
            defaultAction();
          },
        });
      } else {
        lightbox.show();
      }
    }
</script>